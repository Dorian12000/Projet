/*
 * motor_task.h
 *
 *  Created on: Dec 1, 2023
 *      Author: gourd
 */

#ifndef INC_MOTOR_TASK_H_
#define INC_MOTOR_TASK_H_




#endif /* INC_MOTOR_TASK_H_ */
